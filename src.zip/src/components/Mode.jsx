import React, { useContext, useState } from "react";
import Header from "./Header";

function Mode() {
  return (
    <>
      <div></div>
    </>
  );
}

export default Mode;
